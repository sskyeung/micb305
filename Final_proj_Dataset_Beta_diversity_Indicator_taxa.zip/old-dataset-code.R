library(tidyverse)

if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("microbiome")
library(phyloseq)
library(vegan)
library(ggpubr)
library(microbiome)
library(indicspecies)
library(writexl)
library(indicspecies)

metadata = read.delim('parkinsons_metadata 2 2.txt', header = TRUE, row.names = 1)
metadata_PD <- subset(metadata, Disease == "PD")

##33rd and 66th percentile, sd values created too large sample pool of in between and too small of extreme ends
PD_sum = metadata_PD |>
  group_by(Sex) |>
  summarise(
    p33_alpha_carotene = quantile(Alpha_carotene, 0.33, na.rm = TRUE),
    p66_alpha_carotene = quantile(Alpha_carotene, 0.66, na.rm = TRUE),
    p33_beta_carotene = quantile(Beta_carotene, 0.33, na.rm = TRUE),
    p66_beta_carotene = quantile(Beta_carotene, 0.66, na.rm = TRUE),
    p33_Copper = quantile(Copper, 0.33, na.rm = TRUE),
    p66_Copper = quantile(Copper, 0.66, na.rm = TRUE),
    p33_manganese = quantile(Manganese, 0.33, na.rm = TRUE),
    p66_manganese = quantile(Manganese, 0.66, na.rm = TRUE),
    p33_selenium = quantile(Selenium, 0.33, na.rm = TRUE),
    p66_selenium = quantile(Selenium, 0.66, na.rm = TRUE),
    p33_Vitamin_A = quantile(Vitamin_A, 0.33, na.rm = TRUE),
    p66_Vitamin_A = quantile(Vitamin_A, 0.66, na.rm = TRUE),
    p33_Vitamin_C = quantile(Vitamin_C, 0.33, na.rm = TRUE),
    p66_Vitamin_C = quantile(Vitamin_C, 0.66, na.rm = TRUE),
    p33_Vitamin_E = quantile(Vitamin_E, 0.33, na.rm = TRUE),
    p66_Vitamin_E = quantile(Vitamin_E, 0.66, na.rm = TRUE),
    p33_Car_total = quantile(Carotene_total, 0.33, na.rm = TRUE),
    p66_Car_total = quantile(Carotene_total, 0.66, na.rm = TRUE))

PD_grouped = metadata_PD %>% 
  mutate(Age_onset =
           case_when(Age_onset  < 50 ~ "40s",
                     between(Age_onset, 50, 59) ~ "50s",
                     between(Age_onset, 60, 69) ~ "60s",
                     Age_onset >= 70 ~ "70s"))

#PD_male_grouped <- subset(metadata_PD, Sex == "Male")  == 122 patients
#PD_female_grouped <- subset(metadata_PD, Sex == "Female") == 75 patients

PD_binned = PD_grouped |>
  drop_na(Alpha_carotene, Beta_carotene, Copper, Manganese, Selenium, Vitamin_A, Vitamin_C, Vitamin_E, Carotene_total) |>
  mutate(Alpha_carotene =
           case_when(Sex == "Male" & Alpha_carotene > 548.2000 ~ "High",
                     Sex == "Male" & Alpha_carotene < 189.350 ~ "Low",
                     Sex == "Male" & Alpha_carotene ~ "Typical",
                     Sex == "Female" & Alpha_carotene > 571.3539 ~ "High",
                     Sex == "Female" & Alpha_carotene < 541.904 ~ "Low",
                     Sex == "Female" & Alpha_carotene ~ "Typical"),
         Beta_carotene = 
           case_when(Sex == "Male" & Beta_carotene > 3522.162 ~ "High",
                     Sex == "Male" & Beta_carotene < 2229.975 ~ "Low",
                     Sex == "Male" & Beta_carotene ~ "Typical",
                     Sex == "Female" & Beta_carotene > 4992.952 ~ "High",
                     Sex == "Female" & Beta_carotene < 3178.988 ~ "Low",
                     Sex == "Female" & Beta_carotene ~ "Typical"),
         Copper = 
           case_when(Sex == "Male" & Copper > 1.2 ~ "High",
                     Sex == "Male" & Copper < 0.8431575 ~ "Low",
                     Sex == "Male" & Copper ~ "Typical",
                     Sex == "Female" & Copper > 1.276798 ~ "High",
                     Sex == "Female" & Copper < 1 ~ "Low",
                     Sex == "Female" & Copper ~ "Typical"),
         Manganese = 
           case_when(Sex == "Male" & Manganese > 3.088210 ~ "High",
                     Sex == "Male" & Manganese < 2.43 ~ "Low",
                     Sex == "Male" & Manganese ~ "Typical",
                     Sex == "Female" & Manganese > 3.837956 ~ "High",
                     Sex == "Female" & Manganese < 2.574287 ~ "Low",
                     Sex == "Female" & Manganese ~ "Typical"),
         Selenium = 
           case_when(Sex == "Male" & Selenium > 58.29365 ~ "High",
                     Sex == "Male" & Selenium < 42.72238 ~ "Low",
                     Sex == "Male" & Selenium ~ "Typical",
                     Sex == "Female" & Selenium > 65.14686 ~ "High",
                     Sex == "Female" & Selenium < 44.83593 ~ "Low",
                     Sex == "Female" & Selenium ~ "Typical"),
         Vitamin_A =
           case_when(Sex == "Male" & Vitamin_A > 311.4622 ~ "High",
                     Sex == "Male" & Vitamin_A < 191.623 ~ "Low",
                     Sex == "Male" & Vitamin_A ~ "Typical",
                     Sex == "Female" & Vitamin_A > 408.9522 ~ "High",
                     Sex == "Female" & Vitamin_A < 223.012 ~ "Low",
                     Sex == "Female" & Vitamin_A ~ "Typical"),
         Vitamin_C =
           case_when(Sex == "Male" & Vitamin_C > 117.5009 ~ "High",
                     Sex == "Male" & Vitamin_C < 82.31294 ~ "Low",
                     Sex == "Male" & Vitamin_C ~ "Typical",
                     Sex == "Female" & Vitamin_C > 162.6396 ~ "High",
                     Sex == "Female" & Vitamin_C < 108.04810 ~ "Low",
                     Sex == "Female" & Vitamin_C ~ "Typical"),
         Vitamin_E =
           case_when(Sex == "Male" & Vitamin_E > 12.08046 ~ "High",
                     Sex == "Male" & Vitamin_E < 8.652149 ~ "Low",
                     Sex == "Male" & Vitamin_E ~ "Typical",
                     Sex == "Female" & Vitamin_E > 14.09417 ~ "High",
                     Sex == "Female" & Vitamin_E < 10.580000 ~ "Low",
                     Sex == "Female" & Vitamin_E ~ "Typical"),
         Carotene_total =
           case_when(Sex == "Male" & Carotene_total > 3994.850 ~ "High",
                     Sex == "Male" & Carotene_total < 2495.81 ~ "Low",
                     Sex == "Male" & Carotene_total ~ "Typical",
                     Sex == "Female" & Carotene_total > 5651.388 ~ "High",
                     Sex == "Female" & Carotene_total < 3636.83 ~ "Low",
                     Sex == "Female" & Carotene_total ~ "Typical"),)

```
## starting from below is just viewing count

PD_select = PD_binned |>
  select(Alpha_carotene,Beta_carotene, Copper, Manganese, Selenium, Vitamin_A) |>
  drop_na()


Alpha_count = PD_binned |>
  group_by(Age_onset,Sex) |>
  count(Alpha_carotene) |>
  drop_na()

Beta_count = PD_binned |>
  group_by(Age_onset,Sex) |>
  count(Beta_carotene) |>
  drop_na()

Copper_count = PD_binned |>
  group_by(Age_onset,Sex) |>
  count(Copper) |>
  drop_na()

Manganese_count = PD_binned |>
  group_by(Age_onset,Sex) |>
  count(Manganese) |>
  drop_na()

Selenium_count = PD_binned |>
  group_by(Age_onset,Sex) |>
  count(Selenium) |>
  drop_na()

Vitamin_A_count = PD_binned |>
  group_by(Age_onset,Sex) |>
  count(Vitamin_A) |>
  drop_na()

Vit_C_count = PD_binned |>
  group_by(Age_onset,Sex) |>
  count(Vitamin_C) |>
  drop_na()
Vit_E_count = PD_binned |>
  group_by(Age_onset,Sex) |>
  count(Vitamin_E) |>
  drop_na()

Car_total_count = PD_binned |>
  group_by(Age_onset,Sex) |>
  count(Carotene_total) |>
  drop_na()

```

taxonomy = read.delim('taxonomy.tsv', header = TRUE, row.names = "Feature.ID" ) # from qiime2
counts = read.delim('table.txt', skip=1, row.names=1)  # from qiime2
tree = read_tree('tree.nwk')

taxonomy_formatted = taxonomy %>%
  separate(col= Taxon,
           into = c('Domain', 'Phylum', 'Class', 'Order', 'Family', 'Genus', 'Species'),
           sep = '; ', fill = 'right') %>%
  select(-Confidence) %>%
  as.matrix()

counts_formatted = as.matrix(counts)

ps <- phyloseq(sample_data(PD_binned),
               otu_table(counts_formatted, taxa_are_rows = T),
               tax_table(taxonomy_formatted),
               tree)

ps_genus = tax_glom(ps,'Genus')
ps_relab = transform(ps_genus, 'compositional')
ps_filt = filter_taxa(ps_relab, function(x) mean(x) > 0.0001, TRUE)
otu_table = data.frame(otu_table(ps_filt))

set.seed(421)
indval_alpha = multipatt( t(otu_table), 
                    cluster = ps_filt@sam_data$Alpha_carotene,
                    control = how(nperm = 999) )

summary(indval_alpha, indvalcomp = TRUE)

# Extract into table
indval_Alpha_table = as.data.frame(indval$sign)

ISA_Alpha = indval_Alpha_table %>% 
  filter( stat >=0.7, p.value <= 0.05 )

